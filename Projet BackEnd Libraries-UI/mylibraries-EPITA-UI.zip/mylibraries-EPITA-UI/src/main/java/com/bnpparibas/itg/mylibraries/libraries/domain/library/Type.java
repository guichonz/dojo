package com.bnpparibas.itg.mylibraries.libraries.domain.library;

public enum Type {
    ASSOCIATIVE,
    NATIONAL,
    PUBLIC,
    SCHOOL,
    UNIVERSITY;
}