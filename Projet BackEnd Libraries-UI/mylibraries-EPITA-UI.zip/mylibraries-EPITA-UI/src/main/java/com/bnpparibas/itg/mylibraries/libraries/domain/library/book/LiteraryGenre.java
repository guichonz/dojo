package com.bnpparibas.itg.mylibraries.libraries.domain.library.book;

public enum LiteraryGenre {
    COMEDY,
    EPIC,
    FANTASTIC,
    TRAGEDY;
}